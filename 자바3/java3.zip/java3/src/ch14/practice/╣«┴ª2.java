package ch14.practice;



public class 문제2 {

	public static void main(String[] args) {
		 
		
		 
	  /*
	   * 
	   * interface Predicate(T t) {
	   *     boolean  test( T t);
	   * }
	   */

		//위의 interface를 3가지 방법으로 구현하여 실행하시오
		
		//1. 이름이 있는 클래스로 작성하고 객체로 실행하기
		//2. 익명클래스로 만들어 객체로 실행하기
		//3. 람다식을 사용하여 실행하기
	}

}
