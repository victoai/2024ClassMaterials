package com.acorn.di.calculator;

public interface Calculator {	
	int add(int su1, int su2);
}
