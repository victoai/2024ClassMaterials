package com.acorn.cart;

public class OrderDTO {
	
	int orderNo;
	String memberId;
	String goodsNo;
	int qty;
	int amount;
	String  goodsName;
	String option;
	
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	String addr1;
	String addr2;
	String tel;
	String name;
	
	
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public String getAddr1() {
		return addr1;
	}
	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}
	public String getAddr2() {
		return addr2;
	}
	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	 
	public int getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getGoodsNo() {
		return goodsNo;
	}
	public void setGoodsNo(String goodsNo) {
		this.goodsNo = goodsNo;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	@Override
	public String toString() {
		return "OrderDTO [orderNo=" + orderNo + ", memberId=" + memberId + ", goodsNo=" + goodsNo + ", qty=" + qty
				+ ", amount=" + amount + ", goodsName=" + goodsName + ", option=" + option + ", addr1=" + addr1
				+ ", addr2=" + addr2 + ", tel=" + tel + ", name=" + name + "]";
	}
	 
	 
	
	
	

}
