package com.acorn.test;

public class Calculator {
	
	public int add( int su1, int su2) {
		return su1+ su2;
	}
}
