package com.acon.ex;

public class MyException  extends Exception{
	
	 public MyException() {
		 super("예외만들기");
	}

}
