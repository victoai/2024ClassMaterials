package com.acorn.db.di;

public class ProgramTest {

	public static void main(String[] args) { 
		
		/*Program p = new Program();  // 생성 
		Calculator calculator = new Calculator(); //생성		
		p.setCalculator(calculator); //주입
		p.printNumers(5, 3);
*/
	}

}
