package com.acorn.db.di;

import org.springframework.stereotype.Component;

@Component
public class AService {
	
	
	// 
	public String method1() {
		return "service hi";
	}
}
