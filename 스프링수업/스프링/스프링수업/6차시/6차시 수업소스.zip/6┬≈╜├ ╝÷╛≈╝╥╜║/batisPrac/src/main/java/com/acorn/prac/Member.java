package com.acorn.prac;

import lombok.Data;

@Data
public class Member {
	
	String id;
	String pwd;
	String name;

}
