package com.acorn.test;

public interface TestServiceI {		 
	
	public  double[]  위도경도가지오기() ;
	public  int registerMember(Member member);

}
