package com.acorn.test;

public interface GoogleApi {	
	public double[] 위도경도구하기();
}
