package com.acorn.day2.api;

import lombok.Data;

@Data
public class Drama {
	
	String name;
	String actor; 
	
	
}
