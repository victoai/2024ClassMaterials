package com.acorn.day1.di;


public interface Calculator {
	int add( int su1, int su2);
	
}
