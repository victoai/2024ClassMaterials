package com.acorn.parm;

public class LombokTest {

	public static void main(String[] args) {
		 
		
		Member m = new Member();
		m.setAge(0);
	}

}
