package com.acron.di;

public class Test {
	
	
	public void test() {
		System.out.println("test");
	}

}
