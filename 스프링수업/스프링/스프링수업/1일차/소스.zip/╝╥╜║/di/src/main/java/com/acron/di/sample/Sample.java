package com.acron.di.sample;

public class Sample {

}
