package com.acorn.day1.di;

public interface Calculator {
	int daa(int num1 , int num2);
}
