package com.acorn.batis;

public interface d {

}