package com.acorn.batis2;

import lombok.Data;

@Data
public class SearchCondition {

	String condition ;
	String keyword;
	 
}
