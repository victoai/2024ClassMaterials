package com.acorn.day3.drama;

public class Drama {

	String code;
	String title;
	String actors;
	
	public Drama() {
		// TODO Auto-generated constructor stub
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getActors() {
		return actors;
	}

	public void setActors(String actors) {
		this.actors = actors;
	}

	public Drama(String code, String title, String actors) {
		super();
		this.code = code;
		this.title = title;
		this.actors = actors;
	}

//	@Override
//	public String toString() {
//		return "Drama [code=" + code + ", title=" + title + ", actors=" + actors + "]";
//	}
	
	
	
}
