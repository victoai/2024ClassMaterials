package com.acorn.junit2;

import org.springframework.stereotype.Component;

@Component
public class Calculator {
 
	public  int add ( int a, int b) {
		return a+b;
	}
	
}
