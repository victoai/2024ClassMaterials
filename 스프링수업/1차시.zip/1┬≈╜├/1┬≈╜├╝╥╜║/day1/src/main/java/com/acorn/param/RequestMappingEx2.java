package com.acorn.param;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RequestMappingEx2 {
  
    
    @RequestMapping("/modelAttriute")     
    public void test1( User user){ 
        
    	
    	System.out.println( user);
    }
}
