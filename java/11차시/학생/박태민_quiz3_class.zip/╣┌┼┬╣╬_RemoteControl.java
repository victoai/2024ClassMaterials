package day10.quiz;

public class 박태민_RemoteControl {

	public static void main(String[] args) {

		박태민_RemoteControl_class.remote();
	}


}
