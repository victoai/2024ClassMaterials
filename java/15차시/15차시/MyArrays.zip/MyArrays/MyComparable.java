package MyArrays;

public interface MyComparable {
	int compareTo(Object obj);
}
