package prj;

public interface InfoCompare {

	int compareTo(Object o);
}
