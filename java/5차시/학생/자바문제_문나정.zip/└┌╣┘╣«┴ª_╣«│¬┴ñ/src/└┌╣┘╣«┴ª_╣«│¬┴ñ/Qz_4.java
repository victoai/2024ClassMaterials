package 자바문제_문나정;

public class Qz_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int menu =1;
		
		switch(menu){
		case 1:
			System.out.println("1번 등록");
			break;
		case 2:
			System.out.println("2번 조회");
			break;
		case 3:
			System.out.println("3번 변경");
			break;
		case 4:
			System.out.println("4번 삭제");
			break;
			
		}
		

	}

}
