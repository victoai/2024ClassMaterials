package day8.함수실습;

public class Star5_02 {

	// 별 5개를 출력하는 함수 만들기
	
	public static void main(String[] args) {
		
		star();
	}
	
	public static void star() {
		System.out.println("*****");
	}

}
