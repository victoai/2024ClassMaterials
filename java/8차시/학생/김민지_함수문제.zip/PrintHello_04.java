package day8.함수실습;

public class PrintHello_04 {

	public static void main(String[] args) {

		//   "안녕하세요"를 출력하는 함수 만들기
		
		hello();

	}
	
	public static void hello() {
		System.out.println("안녕하세요");
	}

}
