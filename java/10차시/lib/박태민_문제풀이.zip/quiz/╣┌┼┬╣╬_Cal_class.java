package day10.quiz;

public class 박태민_Cal_class {

	public static int plus(int su1, int su2) {		// 더하기
		return su1 + su2;
	}
	public static int minus(int su1, int su2) {		// 빼기
		return su1 - su2;
	}
	public static int multiple(int su1, int su2) {	// 곱하기
		return su1 * su2;
	}
	public static double divide(int su1, int su2) {	// 나누기
		return (double)su1 / su2;
	}
	
}
