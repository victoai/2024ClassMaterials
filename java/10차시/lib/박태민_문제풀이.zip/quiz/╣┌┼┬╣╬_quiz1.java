package day10.quiz;

public class 박태민_quiz1 {

	public static void main(String[] args) {

		박태민_quiz1_class EQ = new 박태민_quiz1_class();
		System.out.println("조절할 볼륨을 기타1, 기타2, 베이스, 드럼, 보컬 순으로 입력하세요");
		EQ.input(0, 0, 0, 0, 0);
		EQ.printVol();
		
	}

}
