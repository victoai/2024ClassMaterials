package 병진_스마트스토어;

public class Item {
	//상품이름
	String itemName = "👏sold out";
	//주문번호
	String itemNum = "👏sold out";
}
