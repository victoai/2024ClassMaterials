package java_day8_class자료형;


public class James {

		int age;
		String name;
		boolean isMarried;
		int children;
	
}
