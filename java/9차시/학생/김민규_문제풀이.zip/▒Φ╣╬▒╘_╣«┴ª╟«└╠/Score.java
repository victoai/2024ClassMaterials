package java_day8_class자료형;

public class Score {
	   String name; 
	   int kor ;
	   int eng ;
	   int avg;    
}
