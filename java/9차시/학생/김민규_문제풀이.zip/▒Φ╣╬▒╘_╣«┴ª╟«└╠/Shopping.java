package java_day8_class자료형;

public class Shopping {
	
	String num;
	String id;
	String date;
	String name;
	String item_Num;
	String item_Adress;
	
	
	
}
