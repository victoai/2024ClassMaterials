package day07;

public class TempEx02 {
	
	public static void main(String[] args) {
		int[]  temperatures = { 27,27,28, 29,30 , 33,32,33,32,31,31,33,33,31} ;
		
		for(int i=0; i<temperatures.length; i++) {
			
			System.out.println(temperatures[temperatures.length-(i+1)]);
			
		}
	}

}
