
package day07;

import java.util.Scanner;

public class FindDivisor {
	public static void main(String[] args) {

		int num;
		int cnt = 0;
		int arr[] = new int[20];

		Scanner sc = new Scanner(System.in);

		num = sc.nextInt();

		for (int i = 1; i <= num; i++) {
			if (num % i == 0) {
				arr[cnt] = i;
				cnt++;
			}
		}
		for(int i=0; i<cnt; i++) {
			System.out.println(arr[i]);
		}
	}
}
