package day07;

public class TempEx04 {
	
	public static void main(String[] args) {
		int[]  temperatures = { 27,27,28, 29,30 , 33,32,33,32,31,31,33,33,31} ;
		int sum=0;
		int avg;
		int cnt=0;
		
		for(int i=0; i<temperatures.length; i++) {
			sum += temperatures[i];
		}
		
		avg = sum/temperatures.length;
		
		
		for(int i=0; i<temperatures.length; i++) {
			if(temperatures[i] > avg) {
				cnt++;
			
			}
		}
		System.out.println(cnt);
	}
}
