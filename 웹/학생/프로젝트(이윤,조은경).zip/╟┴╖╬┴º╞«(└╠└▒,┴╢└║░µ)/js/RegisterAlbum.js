

function check(){
	let frm = document.frm;
	
	let albumId = frm.albumId;
	let albumName = frm.albumName;
	let albumDate = frm.albumDate;
	
	
	if(albumId.value == ""){
		alert("앨범 아이디를 입력하세요");
		albumId.focus();
		return false;
	} else if(albumName.value == ""){
		alert("앨범명를 입력하세요");
		albumName.focus();
		return false;
	} else if(albumDate.value == ""){
		alert("발매일을 입력하세요");
		albumDate.focus();
		return false;
	}
	
	return true;
}