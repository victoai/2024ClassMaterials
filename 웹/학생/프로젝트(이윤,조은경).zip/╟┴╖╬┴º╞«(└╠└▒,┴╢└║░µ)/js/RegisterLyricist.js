

function check(){
	let frm = document.frm;
	
	let LyricistId = frm.LyricistId;
	let LyricistName = frm.LyricistName;
	
	
	
	if(LyricistId.value == ""){
		alert("작사가 아이디를 입력하세요");
		SongId.focus();
		return false;
	} else if(LyricistName.value == ""){
		alert("이름을 입력하세요");
		LyricistName.focus();
		return false;
	} 
	
	return true;
}