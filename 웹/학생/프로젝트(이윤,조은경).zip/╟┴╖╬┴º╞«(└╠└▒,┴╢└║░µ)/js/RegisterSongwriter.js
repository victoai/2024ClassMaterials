

function check(){
	let frm = document.frm;
	
	let SongwriterId = frm.SongwriterId;
	let SongwriterName = frm.SongwriterName;
	
	
	
	if(SongwriterId.value == ""){
		alert("작곡가 아이디를 입력하세요");
		SongwriterId.focus();
		return false;
	} else if(SongwriterName.value == ""){
		alert("이름을 입력하세요");
		SongwriterName.focus();
		return false;
	} 
	
	return true;
}