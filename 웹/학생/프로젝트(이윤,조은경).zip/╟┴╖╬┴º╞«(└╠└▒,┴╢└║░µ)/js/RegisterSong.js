

function check(){
	let frm = document.frm;
	
	let SongId = frm.SongId;
	let SongName = frm.SongName;
	let AlbumId = frm.AlbumId;
	let MemberId = frm.MemberId;
	let LyricistId = frm.LyricistId;
	let SongwriterId = frm.SongwriterId;
	
	
	if(SongId.value == ""){
		alert("곡 아이디를 입력하세요");
		SongId.focus();
		return false;
	} else if(SongName.value == ""){
		alert("곡 제목을 입력하세요");
		SongName.focus();
		return false;
	} else if(AlbumId.value == ""){
		alert("앨범ID를 입력하세요");
		AlbumId.focus();
		return false;
	} else if(MemberId.value == ""){
		alert("멤버ID을 입력하세요");
		MemberId.focus();
		return false;
	} else if(LyricistId.value == ""){
		alert("작사가ID을 입력하세요");
		LyricistId.focus();
		return false;
	} else if(SongwriterId.value == ""){
		alert("작곡가ID을 입력하세요");
		SongwriterId.focus();
		return false;
	}
	
	return true;
}