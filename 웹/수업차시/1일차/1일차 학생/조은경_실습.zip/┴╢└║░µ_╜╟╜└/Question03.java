package prj;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Question03")
public class Question03 extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=utf-8"); //서버가 보내는 데이터의 형식 => html형식임을 알려줌 "text/plain"
		response.setCharacterEncoding("utf-8"); //utf-8형식으로 데이터를 보낸다는 의미
		
		PrintWriter out = response.getWriter();
		
		String num_ = request.getParameter("num");
	
		int num = Integer.parseInt(num_);
		
		
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset=\"UTF-8\">");
		out.println("<title>Question01</title>");
		out.println("<style>");		
		out.println("div { width : 100px; text-align : center; margin : 0 auto; border : 1px solid black; }");
		out.println("</style>");
		out.println("</head>");
		
		out.println("<body>");
		out.println("<div>");
		for(int i =1; i<10; i++) {
			out.print(num + " * " + i + " = " + num*i);
			out.print("<br>");
		}
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	
	}
}
