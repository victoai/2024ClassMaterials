package prj;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Question06")
public class Question06 extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=utf-8"); //서버가 보내는 데이터의 형식 => html형식임을 알려줌 "text/plain"
		response.setCharacterEncoding("utf-8"); //utf-8형식으로 데이터를 보낸다는 의미
		
		PrintWriter out = response.getWriter();
		
		String num_ = request.getParameter("num");
	
		int num = Integer.parseInt(num_);
		
		int[] divisor = new int[30];
		int divisor_cnt = 0;
		// 약수 배열에 담기
		for(int i=1; i<=num ; i++) {
			if(num%i==0) {
				divisor[divisor_cnt] = i;
				divisor_cnt++;
			}
		}
		
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset=\"UTF-8\">");
		out.println("<title>Question01</title>");
		out.println("<style>");		
		out.println("div { width : 300px; text-align : center; margin : 0 auto; border : 1px solid black; }");
		out.println("</style>");
		out.println("</head>");
		
		out.println("<body>");
		out.println("<div>");
		out.println("약수 : ");
		// 약수 배열 출력
		for(int i=0; i<divisor_cnt-1 ; i++) {
			if(i == divisor_cnt-2) {
				out.println(divisor[i] + " ");				
			}else {
				out.println(divisor[i] + ", ");				
			}
		}
		out.println("<br>약수의 개수 : " + (divisor_cnt-1));
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
		
		
	
	}
}
