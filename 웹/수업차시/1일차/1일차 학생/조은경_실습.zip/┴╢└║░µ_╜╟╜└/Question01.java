package prj;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Question01")
public class Question01 extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String su1_ = request.getParameter("su1");
		String su2_ = request.getParameter("su2");
		
		int su1 = Integer.parseInt(su1_);
		int su2 = Integer.parseInt(su2_);
		
		int sum;
		int sub;
		int mul;
		float div;
		
		if(su1 >= su2) {
			sum = su1 + su2;
			sub = su1 - su2;
			mul = su1 * su2;
			div = su1 / su2;
		}else {
			sum = su2 + su1;
			sub = su2 - su1;
			mul = su2 * su1;
			div = su2 / su1;
		}
		
		
				
		response.setContentType("text/html;charset=utf-8"); //서버가 보내는 데이터의 형식 => html형식임을 알려줌 "text/plain"
		response.setCharacterEncoding("utf-8"); //utf-8형식으로 데이터를 보낸다는 의미
	
		PrintWriter out = response.getWriter();
		
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset=\"UTF-8\">");
		out.println("<title>Question01</title>");
		out.println("<style>");		
		out.println("div { width : 100px; height : 100px; margin : 0 auto; border : 1px solid black; }");
		out.println("</style>");
		out.println("</head>");
		
		out.println("<body>");
		out.println("<div>");
		out.println("덧셈 : " + sum + "<br>");
		out.println("뺄셈 : " + sub + "<br>");
		out.println("곱셈 : " + mul + "<br>");
		out.println("나눗셈 : " + div + "<br>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	
	}
	

}
