//package 실습10차시;
//
//public class ShoppingMall {
//	
//	public static void main(String[] args) {
//		
//		
//		Customer customer = new Customer();
//		
//		customer.inputData("김현수", "khs220507", "220507", "서울시 용산구");
//		
//		customer.printInfo();
//	}
//}
