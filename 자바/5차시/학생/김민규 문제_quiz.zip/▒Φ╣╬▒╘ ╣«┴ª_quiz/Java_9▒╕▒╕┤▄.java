package java_day4.quiz;

public class Java_9구구단 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int	sum=2;
		for(int i=1; i<=9; i++) { // i+=2
		
			System.out.println((sum*i));
		}
	}

}
