package java_day4.quiz;

public class Java_3고객정보 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age= 27;
		String name= "김민규";
		 boolean isAdult =true;
		 int height = 189;
		
		
		
		System.out.println("이름 "+name+" 나이 "+age+" 성인 "+isAdult + "키" + height);
		
	}
	
	

	
	
}
