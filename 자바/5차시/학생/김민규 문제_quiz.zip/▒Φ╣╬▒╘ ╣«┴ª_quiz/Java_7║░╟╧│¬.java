package java_day4.quiz;

public class Java_7별하나 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	//별하나 문제	
		System.out.println("*");

	}

}
