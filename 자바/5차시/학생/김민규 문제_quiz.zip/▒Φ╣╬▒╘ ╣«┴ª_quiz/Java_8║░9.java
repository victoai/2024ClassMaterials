package java_day4.quiz;

public class Java_8별9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 별하나 문제

		for (int i = 1; i <= 3; i++) {
			for (int j = 1; j <= 3; j++) {

				System.out.print("*");

			}
			System.out.println(" ");
		}
	}
}
