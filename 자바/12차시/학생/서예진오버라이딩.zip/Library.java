package day12;

public class Library {

	public void borrow() {
		System.out.println("대출가능합니다.");
	}
	public void RReturn() {
		System.out.println("반납해주세요.");
	}
	public void overdue() {
		System.out.println("연체되었습니다.");
	}
}
