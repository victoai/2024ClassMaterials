package day12;

public class 자바의정석 extends Library {
	public void already_B() {
		System.out.println("이미 대출하셨습니다.");
	}
}
