package day09.quiz;

public class quiz_class01_class {
	
// 사람정보
	
int age;
String name;
String gender;
boolean isMarried;
int child;

}
