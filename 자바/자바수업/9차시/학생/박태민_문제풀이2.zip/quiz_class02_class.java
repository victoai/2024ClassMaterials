package day09.quiz;

public class quiz_class02_class {
	
// 쇼핑몰 주문
	
long orderNum;
String id;
String orderDate;
String orderName;
String merchandiseNum;
String address;
}
