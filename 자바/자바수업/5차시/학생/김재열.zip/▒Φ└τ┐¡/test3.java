package 문법.day4;

public class test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String ID = "dhdl2389";
		String name = "김재열";
		int age = 28;
		double height = 182.19;

		System.out.println(ID + name + age + height);

	}

}
