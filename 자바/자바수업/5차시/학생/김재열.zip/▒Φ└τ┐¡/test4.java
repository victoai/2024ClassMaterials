package 문법.day4;

public class test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int menu = 1;
		switch (menu = 1) {
		case 1:
			System.out.println("등록");
			break;

		case 2:
			System.out.println("조회");
			break;

		case 3:
			System.out.println("변경");
			break;

		case 4:
			System.out.println("삭제");
			break;

		default:
			System.out.println("잘못된 입력");
			break;

		}
	}

}
