package day04;

public class Practice07 {
	
	public static void main(String[] args) {
		System.out.println("*");
	}

}
