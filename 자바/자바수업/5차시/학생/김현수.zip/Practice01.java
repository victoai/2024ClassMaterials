package day04;

public class Practice01 {
	
	public static void main(String[] args) {
		
		int sum = 0;
		
		int num = 1;
		
		while(num<=10) {
			sum += num;
			num++;
		}
		
		System.out.println("1부터 10까지의 총합 : " + sum + " 입니다.");
	
		
	}

}
