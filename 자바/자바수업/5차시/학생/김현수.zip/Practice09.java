package day04;

import java.util.Scanner;

public class Practice09 {
	public static void main(String[] args) {
		int num;
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		
		for(int i=1; i<10; i++) {
			System.out.println(num*i);
		}
		
	}

}
