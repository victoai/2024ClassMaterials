package day5;

public class StarLine3_8 {

	public static void main(String[] args) {
		
	for (int j=0; j<3; j++) {
		
		for(int i=0; i<3; i++) {
			System.out.print("*");
		}
		System.out.println();
		
	}

	}

}
