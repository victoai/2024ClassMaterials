package day5;

public class StarOne_7 {

	public static void main(String[] args) {
		
		System.out.println("*");

	}

}
