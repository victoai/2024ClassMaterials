package day5;

public class Test07 {

	public static void main(String[] args) {
// 7. * (별하나 출력)
System.out.println("*");


	}

}
