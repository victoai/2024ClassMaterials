package day4;

import java.util.Scanner;

public class test08 {

	public static void main(String[] args) {

		
		System.out.print("\n--------------8번--------------\n");
		
		
		for(int i=1; i<=3; i++) {
			for(int j=1; j<=3; j++) {
				System.out.print("*");
			}
			System.out.println("");
		}
		
		
		
		
		
	}

}
