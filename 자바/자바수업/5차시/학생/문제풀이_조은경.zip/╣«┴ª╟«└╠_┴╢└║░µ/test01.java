package day4;

import java.util.Scanner;

public class test01 {

	public static void main(String[] args) {

		
		System.out.print("--------------1번--------------\n");

		int sum1 = 0;
		for (int i = 1; i <= 10; i++) {
			sum1 += i;
		}
		System.out.println("1~10까지의 합 : " + sum1);

		
	}

}
