package day4;

import java.util.Scanner;

public class test07 {

	public static void main(String[] args) {

		
		System.out.print("\n--------------7번--------------\n");
		
		System.out.println("*");
		
		
		
		
		
		
	}

}
