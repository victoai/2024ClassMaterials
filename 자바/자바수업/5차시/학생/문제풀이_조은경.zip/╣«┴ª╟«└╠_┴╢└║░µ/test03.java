package day4;

import java.util.Scanner;

public class test03 {

	public static void main(String[] args) {

		

		System.out.print("\n--------------3번--------------\n");

		Scanner sc3 = new Scanner(System.in);
		String id = sc3.next();
		String name = sc3.next();
		int age = sc3.nextInt();
		double height = sc3.nextInt();
		System.out.println("아이디 : " + id);
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		System.out.println("키 : " + height);

		
		
	}

}
