package day5;

public class no1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=0;
		int sum=0;
		while(true) {  // 무한반복 , 탈출조건 반드시 있어야 함 
			i++;
			sum = sum + i; //  sum+=i;
			if( i >=10) break;			
		}		
		System.out.println( sum);

	}

}
