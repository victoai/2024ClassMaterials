package day5;

public class no8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
