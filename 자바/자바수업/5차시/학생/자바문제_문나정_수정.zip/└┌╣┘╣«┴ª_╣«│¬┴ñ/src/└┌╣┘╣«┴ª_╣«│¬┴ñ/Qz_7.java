package 자바문제_문나정;

public class Qz_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("*");

	}

}
