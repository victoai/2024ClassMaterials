package 자바문제_문나정;

public class Qz_8 {

	public static void main(String[] args) {

		for(int i=0; i<3; i++) {
			for(int j=0; j<3; j++) {
				System.out.print("*");
			}
			System.out.print("\n");
		}
	}

}
