package day14.equals오버라이드복습;

public class Ek_Student extends Student{
	
	@Override
	public void 음료마시기() {
		System.out.println("딸기스무디를 마신다");
	}
	
}
