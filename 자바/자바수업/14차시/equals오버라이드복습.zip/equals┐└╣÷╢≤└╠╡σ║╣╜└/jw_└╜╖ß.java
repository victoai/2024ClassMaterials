package day14.equals오버라이드복습;

public class jw_음료 extends Student{

	@Override
	public void 음료마시기() {
		System.out.println("딸기스무디");
	}
	
}
