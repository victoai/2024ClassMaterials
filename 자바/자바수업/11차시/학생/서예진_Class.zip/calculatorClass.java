package com.acorn_SYJ;

public class calculatorClass {
	public static  int add(int a, int b) {
		int r=a+b;
		return r;
	}
	public static int minus(int a,int b) {
		int r=a-b;
		return r;
	}
	public static int ddouble(int a,int b) {
		int r=a*b;
		return r;
	}
	public static double divi(int a, int b) {
		return(double)a/b;
	}
}

	
