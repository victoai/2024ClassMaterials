package com.acorn_SYJ;

public class calculatorTest {

	public static void main(String[] args) {

		//calculatorClass C = new calculatorClass();
		int a=20, b=3;
		
		System.out.println(calculatorClass.add(a, b));
		System.out.println(calculatorClass.minus(a, b));
		System.out.println(calculatorClass.ddouble(a, b));
		System.out.println(calculatorClass.divi(a, b));
		
		
	}

}
