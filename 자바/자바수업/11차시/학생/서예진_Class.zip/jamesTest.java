package com.acorn_SYJ;

public class jamesTest {

	public static void main(String[] args) {
		
		jamesInfo J = new jamesInfo();
		
		J.input("james", 40, 3, true);
		J.printInfo();
		
	}

}
