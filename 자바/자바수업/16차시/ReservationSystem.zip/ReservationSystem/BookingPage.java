package ReservationSystem;

public class BookingPage {

}
