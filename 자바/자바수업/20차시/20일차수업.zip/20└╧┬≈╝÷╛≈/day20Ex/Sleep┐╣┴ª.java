package day20Ex;

 

public  class Sleep예제 {
	public static void main(String[] args)  	{
		 
 
		//스레드 실행 요청 ,스레드시작됨
		MyThread4 th1 = new MyThread4();
		th1.start();			
		 
	 
	}
}


 