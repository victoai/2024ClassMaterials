package javaprj.day0128.day20Ex;

 

public  class Join미사용 {
	public static void main(String[] args)  	{		 
 
		//스레드 실행 요청 ,스레드시작됨
		MyThread4 th1 = new MyThread4();
		th1.start(); 
		System.out.println("main 종료");
		 
	 
	}
}


 