package javaprj.day0128.day20Ex.thread.예제;

public class CameraThread extends Thread{
	@Override
	public void run() {
		System.out.println("**********찰칵***********");
	}
}
