package day13.오버라이드;


public class 김민지사람  extends Person{ 
	
	public void dance2() {
		System.out.println("아이돌 댄스를 춘다");
	}
	
	
}
