package day13.오버라이드;

public class 김민규사람  extends  Person{

	
	@Override
	public void dance() {
		// TODO Auto-generated method stub
		 System.out.println("살사를 춘다");
	}
}
