package day13.오버라이드;

public class Person {
	
	public void dance() {
		System.out.println("사람은 춤을 춘다");
	}

}
