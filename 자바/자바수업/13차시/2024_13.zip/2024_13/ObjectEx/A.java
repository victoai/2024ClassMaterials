package day13.ObjectEx;

public class A {
	
	@Override
	public String toString() {		 
		return  "A객체의 정보" ;
	}

}
