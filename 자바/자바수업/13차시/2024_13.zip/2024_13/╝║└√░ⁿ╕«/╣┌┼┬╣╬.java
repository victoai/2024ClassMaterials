package day13.성적관리;

public class 박태민 {
	 
	
	@Override
	public String toString() {
		return  "박태민입니다";
	}
}
