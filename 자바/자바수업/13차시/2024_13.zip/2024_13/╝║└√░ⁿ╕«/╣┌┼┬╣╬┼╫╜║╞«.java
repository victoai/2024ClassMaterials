package day13.성적관리;

public class 박태민테스트 {

	public static void main(String[] args) {

		박태민 a = new 박태민();		
		System.out.println( a.toString());		
		Object o = a;  /// ok  업캐스팅		
		System.out.println( o);
		
		
	}

}
