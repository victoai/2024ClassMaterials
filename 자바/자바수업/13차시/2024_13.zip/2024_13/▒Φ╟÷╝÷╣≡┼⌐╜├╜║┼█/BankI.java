package day13.김현수뱅크시스템;

public interface BankI {
	
	public void deposit(int Money);
	
	public void withdraw(int Money);
	
	public void overrallPrint(
			
			);
	
}
