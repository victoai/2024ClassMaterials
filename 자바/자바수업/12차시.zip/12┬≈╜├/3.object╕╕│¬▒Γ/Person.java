package 다형성예제;

public class Person {
	
	  @Override
	public String toString() {
		  return "사람정보";
	}

}
