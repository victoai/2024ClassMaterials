package 다형성예제;


//모든클래스는 상속을 받지 않으면  Object를 상속받는다 !!

public class Cat {
	
	@Override
	public String toString() {
		   return "고양이정보";
	}

}
