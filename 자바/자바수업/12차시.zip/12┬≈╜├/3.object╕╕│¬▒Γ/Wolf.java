package 다형성예제;

public class Wolf {

}
