package 다형성예제;

public class Car {
	
	@Override
	public String toString() {
		   return "카정보";
	}

}
