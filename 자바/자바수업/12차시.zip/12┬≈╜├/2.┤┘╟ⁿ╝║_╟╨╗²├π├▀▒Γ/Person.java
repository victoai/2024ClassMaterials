package day12.다형성예제;

class  Person {
    public void dance(){
        System.out.println("사람이  춤을 춘다"); 
    }
}
