package day12.업다운캐스팅.민규님;

public class Pizza {

	public void 도우() {
		System.out.println("도우");
	}
	public void 치즈() {
		System.out.println("치즈");
	}

	public void 올리브() {
		System.out.println("올리브");
	}
	public void 양파() {
		System.out.println("양파");
	}
	public void 페퍼로니() {
		System.out.println("페퍼로니");
	}
	public void 소스() {
		System.out.println("토마토소스");
	}
	public void 소시지() {
		System.out.println("소시지");
	}

	
	
}
