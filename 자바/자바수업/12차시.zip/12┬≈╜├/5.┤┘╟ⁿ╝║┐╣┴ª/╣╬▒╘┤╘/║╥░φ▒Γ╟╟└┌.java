package day12.업다운캐스팅.민규님;

public class 불고기피자 extends Pizza{

	
	public void 불고기() {
		
		System.out.println("불고기");
	
	//부모의매서드를 재정의
	//오버라이드
	//부모의 매서드를 재정의 할때 입력,반환 정보가 같아야함

	}
	public void 소스() {
		System.out.println("불고기소스");
	}
}
