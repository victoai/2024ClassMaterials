package javaprj.day0205;

public class CatTest {

	public static void main(String[] args) {
	 		
		Cat c = new Cat();
		c.먹는다();

	}

}
