package day12.인터페이스;

public class 태민계산기클래스 {
	
	public int  add태민(int su1, int su2) {
		return su1+ su2;
	}

	public int  sub태민(int su1, int su2) {
		return su1 -  su2;
	}
	
	public int  multi태민(int su1, int su2) {
		return su1* su2;
	}
	
	
	public int  devide태민(int su1, int su2) {
		return su1/ su2;
	}
}
