package day12.다형성예제_Object;

public class Person {
	
	public String toString() {
		return "사람정보";
	}

}
