package day12.다형성예제_Object;

public class Cat {
	
	public String toString() {
		return "고양이 정보";
	}
	public void 쥐를잡는다() {
		System.out.println("쥐를 잡는다");
	}

}
