package day12.다형성예제_Object;

public class Car   {
	
	@Override
	public String toString() {
		return "카정보";
	}
}
