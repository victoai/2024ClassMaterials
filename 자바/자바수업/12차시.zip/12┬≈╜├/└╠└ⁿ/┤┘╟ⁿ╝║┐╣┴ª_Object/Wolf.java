package day12.다형성예제_Object;

public class Wolf {

}
