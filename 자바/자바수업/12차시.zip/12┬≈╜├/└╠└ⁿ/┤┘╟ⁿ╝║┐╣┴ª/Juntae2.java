package day12.다형성예제;

class  Juntae2 extends Person2  {

	@Override
	public void dance() {
		System.out.println("칼춤을 춘다.");
		
	}
	
}
