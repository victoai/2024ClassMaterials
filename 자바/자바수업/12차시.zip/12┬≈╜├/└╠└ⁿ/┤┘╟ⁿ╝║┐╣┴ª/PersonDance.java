package day12.다형성예제;

public class PersonDance extends Person {
	@Override
	public void dance() {
		System.out.println("머리를 돌리며");
	}
}
