package day12.다형성예제;

public class Dance_NJ extends Person {

	@Override
	public void dance() {
		System.out.println("커버 댄스를 춘다");
	}
}
