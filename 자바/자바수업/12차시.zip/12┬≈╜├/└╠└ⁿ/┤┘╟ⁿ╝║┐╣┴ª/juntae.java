package day12.다형성예제;

class  juntae extends Person {
	@Override
    public void dance(){
             System.out.println("비보잉을 한다."); 
    }
}
