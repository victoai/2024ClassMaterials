package day12.다형성예제;

public class PersonMin extends Person {

	@Override
	public void dance() {
		System.out.println("뉴진스의 하입보이요");

	}
	
}
