package day12.다형성예제;

public class DunDun2 extends Person2{

	@Override
	public void dance() {
		System.out.println("오마이걸 던던댄스를 춘다. 둠칫둠칫");
		
	}
	 
 
}
