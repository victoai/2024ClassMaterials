package day12.다형성예제;

public class Kjy2 extends Person2{

	@Override
	public void dance() {
		 
		
	}

}
