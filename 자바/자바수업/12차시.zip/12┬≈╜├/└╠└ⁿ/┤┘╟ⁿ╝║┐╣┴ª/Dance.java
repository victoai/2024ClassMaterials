package day12.다형성예제;

public class Dance extends Person{

	@Override
	
	public void dance() {
		System.out.println("비보잉을 화려하게 한다");
	}
}
