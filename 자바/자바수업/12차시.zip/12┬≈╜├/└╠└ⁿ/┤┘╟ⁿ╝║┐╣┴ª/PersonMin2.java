package day12.다형성예제;

public abstract class PersonMin2 extends Person2 {

	@Override
	public void dance() {
		System.out.println("뉴진스의 하입보이요");

	}
	
}
