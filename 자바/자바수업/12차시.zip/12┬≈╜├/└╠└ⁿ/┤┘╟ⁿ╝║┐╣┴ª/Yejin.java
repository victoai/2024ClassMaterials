package day12.다형성예제;

public class Yejin extends Person {
	
	@Override
	public void dance(){
			System.out.println("팝핀을 춘다");
		}
	
}
