package day12.다형성예제;

public class Dance_JH extends Person{
	
	/*
	@Override
	public void dance() {
		System.out.println("돌면서 춤을 춘다.");
	}
*/
}
