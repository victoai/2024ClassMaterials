
public class Day {
	private String work;
	
	public void setWork(String work) {
		this.work = work;
	}
	public String getWork() {
		return work;
	}
	public void show() {
		System.out.println(work +"입니다. ");
	}
}

