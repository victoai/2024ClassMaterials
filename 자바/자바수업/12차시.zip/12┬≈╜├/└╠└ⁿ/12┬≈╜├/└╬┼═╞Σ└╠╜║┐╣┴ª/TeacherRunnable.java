package 인터페이스예제;


// 인퍼테이스를 상속하여 기능을 구현하시오
public interface TeacherRunnable {	
	public void runYourCode();
}
