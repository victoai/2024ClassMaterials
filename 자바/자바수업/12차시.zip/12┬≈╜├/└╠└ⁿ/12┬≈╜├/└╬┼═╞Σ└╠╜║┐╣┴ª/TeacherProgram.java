package 인터페이스예제;

public class TeacherProgram {
	
	public static void run( TeacherRunnable r){
		r.runYourCode();
		
	}

	
	public static void main(String[] args) {		

      // run(   TeacherRunnable을 구현한 객체를 매개변수로 넣어줌 ) ;

	}

}
