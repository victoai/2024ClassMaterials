package Car;

import java.util.ArrayList;

public class OpenableTest {

	public static void main(String[] args) {
		
		
		 ArrayList<Openable> list = new ArrayList<>();		 
		 list.add( new Blackcar());
		 list.add( new Redcar());
		 
		 
		 

	}

}
