package Car;

public interface Openable {
	 
	
	public void open () ;

}
