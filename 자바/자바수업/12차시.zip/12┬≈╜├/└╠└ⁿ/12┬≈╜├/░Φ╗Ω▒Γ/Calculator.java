package prjDay11.계산기;



public interface Calculator {
	
	 public int addAcorn(int num1,int num2) ;    // 추상매서드만드로 이루어짐
	 public int subAcorn(int num1,int num2) ;    // 추상매서드만드로 이루어짐
	 public int multiplyAcorn(int num1,int num2) ;    // 추상매서드만드로 이루어짐
	 public double devideAcorn(int num1,int num2);
	 
}
