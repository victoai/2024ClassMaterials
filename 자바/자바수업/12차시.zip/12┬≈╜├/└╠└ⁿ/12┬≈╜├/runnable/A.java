package prjDay11.runnable;

public class A   implements MyRunnable{

	@Override
	public void run() {
	    System.out.println(" 실행됨  !!!!");
		
	}

}
