package prjDay11.runnable;

public class Dayoff implements MyRunnable{

	@Override
	public void run() {
		System.out.println("쉬는 날~");
		System.out.println("2월20일(월)");
		System.out.println("2월21일(화)");
		System.out.println("3월1일(수)");
		System.out.println("3월2일(목)");
		System.out.println("3월3일(금)");
		System.out.println("이 뒤로는 5월까지 없습니다 ㅜㅜ ");
		
	}

}
