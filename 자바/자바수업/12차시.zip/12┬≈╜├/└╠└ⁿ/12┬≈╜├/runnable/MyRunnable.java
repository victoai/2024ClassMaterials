package prjDay11.runnable;

public interface MyRunnable {
	
	public void run();
}
