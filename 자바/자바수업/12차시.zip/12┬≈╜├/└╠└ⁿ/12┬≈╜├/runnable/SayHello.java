package prjDay11.runnable;

public class SayHello  implements MyRunnable{

		@Override
		public void run() {
			System.out.println("안녕하세요! 좋은 하루 보내시길 바랄게요.");
		}
}
