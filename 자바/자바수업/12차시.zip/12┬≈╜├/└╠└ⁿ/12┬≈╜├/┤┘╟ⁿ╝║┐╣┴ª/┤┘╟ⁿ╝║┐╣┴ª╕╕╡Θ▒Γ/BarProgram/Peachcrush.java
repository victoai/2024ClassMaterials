package prjDay10.inheritance.Bar;

public class Peachcrush extends Cocktail {
	
	public void Cocktail() {
		System.out.println("피치리큐르 + 스위트사워믹스 + 크랜베리쥬스");
	}
	
	
	public void Peachcrush() {
		System.out.println("피치크러시");
	}

}
