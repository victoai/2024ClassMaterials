package 과제;

public class Nuguri extends Jin {
	public void 다시마() {
		System.out.println("다시마를 넣는다.");
	}
}
