package Car;

public class Car {
	
	public void go() {
		System.out.println("차가 나갑니다. 부릉부릉");
	}
	

	
	
	
	
}
