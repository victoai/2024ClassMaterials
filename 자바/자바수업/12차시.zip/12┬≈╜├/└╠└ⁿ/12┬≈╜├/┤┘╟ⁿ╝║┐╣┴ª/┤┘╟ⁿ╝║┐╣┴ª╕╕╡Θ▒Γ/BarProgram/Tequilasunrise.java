package prjDay10.inheritance.Bar;

public class Tequilasunrise extends Cocktail {

	public void Cocktail() {
		System.out.println("데킬라 + 오렌지쥬스 + 석류시럽");
	}
	
	public void Tequilasunrise() {
		System.out.println("데킬라선라이즈");
	}
}
