package inheritance실습;

public class Dog extends Animal_Training {
	
	public void 울어() {
		System.out.println("멍!멍!");
	}
	
	public void 기다려() {
		System.out.println("낑..");
	}
	
	public void 집지키기() {
		System.out.println("집을 지킨다");
	}

}
