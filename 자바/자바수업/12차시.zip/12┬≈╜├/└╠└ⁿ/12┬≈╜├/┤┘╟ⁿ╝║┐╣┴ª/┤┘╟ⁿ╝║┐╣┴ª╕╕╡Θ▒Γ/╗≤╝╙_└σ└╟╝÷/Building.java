package 상속_장의수;

public class Building {
	String name;
	String where;
	public Building(){}
	public Building(String name, String where){
		this.name = name;
		this.where=where;
	}
	public void move () {
		
	}
}
