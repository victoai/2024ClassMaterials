package prjDay10.inheritance.Bar;

public class Cocktail {

	public void Cocktail() {
		System.out.println("칵테일을 상속하여 선택해주세요");
	}
}
