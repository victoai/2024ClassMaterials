package prjDay11;

public class SayHello  implements MyRunnable{

		@Override
		public void sayHello() {
			System.out.println("안녕하세요! 좋은 하루 보내시길 바랄게요.");
		}
}
