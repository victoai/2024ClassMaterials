package prjDay11;

public class Vehicle {
	    public void run() {
	        System.out.println("차량이 달립니다.");
	    }
	    
	    public void stop() {
	    	System.out.println("차량이 멈춥니다.");
	    }
	
}
