package inheritance실습;

public class Wolf extends Animal_Training {
	
	public void 울어() {
		System.out.println("아우~!");
	}
	
	public void 공격() {
		System.out.println("???");
	}

}
