package prjDay11.Jsp;

public class Sleep extends Home {
	public void activity() {
		System.out.println("방에가기");
	}
	public void sleepp() {
		System.out.println("잔다");
	}
}
