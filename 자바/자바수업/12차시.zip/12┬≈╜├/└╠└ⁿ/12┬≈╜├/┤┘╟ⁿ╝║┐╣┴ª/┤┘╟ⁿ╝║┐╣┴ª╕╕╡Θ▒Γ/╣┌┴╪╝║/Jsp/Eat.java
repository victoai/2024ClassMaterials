package prjDay11.Jsp;

public class Eat extends Home{
	public void activity(){
		System.out.println("배민켜기");
	}
	public void meal() {
		System.out.println("식사하기");
	}
}
