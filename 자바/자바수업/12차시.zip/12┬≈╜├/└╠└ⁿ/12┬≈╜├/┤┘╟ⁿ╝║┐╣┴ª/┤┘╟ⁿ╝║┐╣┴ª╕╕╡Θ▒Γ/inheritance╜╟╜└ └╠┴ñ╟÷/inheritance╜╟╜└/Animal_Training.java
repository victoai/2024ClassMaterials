package inheritance실습;

public class Animal_Training {
	
	public void 기다려() {
		System.out.println("기다린다");
	}
	
	public void 먹어() {
		System.out.println("먹는다");
	}
	
	public void 달려() {
		System.out.println("달린다");
	}
	
	public void 울어() {
		System.out.println("짖는다");
	}

}
