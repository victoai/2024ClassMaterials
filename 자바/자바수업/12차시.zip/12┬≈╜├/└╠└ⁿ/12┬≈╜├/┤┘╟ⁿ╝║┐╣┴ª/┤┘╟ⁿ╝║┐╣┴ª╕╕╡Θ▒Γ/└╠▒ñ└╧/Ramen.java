package 과제;

public class Ramen {
	public void 물() {
		System.out.println("물을 끓인다.");
	}
	public void 면() {
		System.out.println("면을 넣는다.");
	}
	public void 먹기() {
		System.out.println("맛있게 먹는다.");
	}
}
