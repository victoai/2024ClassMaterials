package 상속_장의수;

public class Person {
	String name;
	public Person() {
}
public Person(String name) {
		this.name = name;
	}
}
