package 과제;

public class Jin extends Ramen {
	public void 스프() {
		System.out.println("스프를 넣는다.");
	}
}
