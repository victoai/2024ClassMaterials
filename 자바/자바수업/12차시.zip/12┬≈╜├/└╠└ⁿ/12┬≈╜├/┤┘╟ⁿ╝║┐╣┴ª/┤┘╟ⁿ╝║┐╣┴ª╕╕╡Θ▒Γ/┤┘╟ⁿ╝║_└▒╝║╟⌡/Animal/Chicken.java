package Animal;

public class Chicken extends Animal{

	public void bark() {
		System.out.println("꼬끼오");
	}
	public void 날기() {
		System.out.println("날았다");
	}
}