package prjDay11;

public class VehicleEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 	Car c = new Car();
	        Bus b = new Bus();
	        Motorcycle m = new Motorcycle();
	        
	        c.run();
	        c.stop();
	        
	        
	        b.run();
	        b.stop();
	        
	        
	        m.run();
	        m.stop();
	        
	        
	}

}
