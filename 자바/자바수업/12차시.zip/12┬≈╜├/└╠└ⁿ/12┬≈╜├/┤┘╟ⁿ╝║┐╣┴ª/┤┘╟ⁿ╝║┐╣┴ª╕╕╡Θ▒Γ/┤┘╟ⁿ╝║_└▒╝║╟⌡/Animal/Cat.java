package Animal;

public class Cat extends Animal{

	public void bark() {
		System.out.println("야옹");
	}
	
	public void 잠자기() {
		System.out.println("잠을 잤다");
	}
}
