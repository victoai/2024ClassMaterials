package Animal;

public class Dog extends Animal{

	public void bark() {
		System.out.println("멍멍");
	}
	public void 냄새맡기() {
		System.out.println("냄새를 맡았다");
	}
}
