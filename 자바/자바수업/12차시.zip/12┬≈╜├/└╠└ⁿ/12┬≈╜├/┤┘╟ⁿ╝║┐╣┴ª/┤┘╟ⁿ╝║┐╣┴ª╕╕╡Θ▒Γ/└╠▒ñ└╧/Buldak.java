package 과제;

public class Buldak extends Ramen {
	public void 물버리기() {
		System.out.println("물을 버린다.");
	}

	public void 볶기() {
		System.out.println("소스를 넣고 면을 볶는다.");
	}
}
