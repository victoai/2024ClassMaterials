package prjDay11;

public class Car extends Vehicle {

	  public void run() {
	        System.out.println("자동차가 달립니다.");
	    }
	  
	  public void stop() {
	    	System.out.println("자동차가 멈춥니다.");
	    }
}
