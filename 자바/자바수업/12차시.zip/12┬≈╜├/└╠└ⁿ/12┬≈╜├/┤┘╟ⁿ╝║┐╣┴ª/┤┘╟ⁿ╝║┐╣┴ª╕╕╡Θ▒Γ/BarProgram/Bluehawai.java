package prjDay10.inheritance.Bar;

public class Bluehawai extends Cocktail {

	
	public void Cocktail() {
		System.out.println("블루큐라소 + 화이트럼 + 파인애플쥬스+ 레몬쥬스");
	}
	
	public void Bluehawai() {
		System.out.println("블루하와이");
	}
}
