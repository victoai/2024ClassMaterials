package inheritance실습;

public class Cat extends Animal_Training {
	
	public void 울어() {
		System.out.println("야옹!");
	}
	
	public void 기다려() {
		System.out.println("고양이가 그 말을 들을리가");
	}
	
	public void 츄르() {
		System.out.println("후다닥!");
	}

}
