package 과제;

public class Order {
	
	public void menuname() {}
	
    public void menu() {
    	System.out.println("메뉴로는 김밥, 떡볶이, 라면이 있습니다.");	
	}
	
	public void ordermenu() {
		System.out.println("메뉴를 선택하세요");
	}
}
