package prjDay11;

	public interface MyRunnable {
		
		public void sayHello();
	}

