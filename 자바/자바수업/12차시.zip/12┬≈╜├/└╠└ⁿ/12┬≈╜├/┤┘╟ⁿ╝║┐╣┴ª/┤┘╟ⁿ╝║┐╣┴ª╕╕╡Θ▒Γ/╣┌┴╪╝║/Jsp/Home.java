package prjDay11.Jsp;

public class Home{
	public void activity() {
		System.out.println("활동한다");
	}
}
