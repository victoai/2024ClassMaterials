package prjDay11;

public class Motorcycle extends Vehicle{

	 public void run() {
	        System.out.println("오토바이가 달립니다.");
	    }
	 
	 public void stop() {
	    	System.out.println("오토바이가 멈춥니다.");
	    }
}
