package Animal;

public class Llama extends Animal{

	public void bark() {
		System.out.println("???");
	}
	public void 침뱉기() {
		System.out.println("침을 뱉었다");
	}
}
