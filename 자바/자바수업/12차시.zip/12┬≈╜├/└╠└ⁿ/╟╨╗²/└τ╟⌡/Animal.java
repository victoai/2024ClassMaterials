package java_day12.상속연습;

public class Animal {
	
	
	String name;
	String fname;
	
	
	
	public Animal() {
		this("동물이름","별명"); 
		
		
	}
	
	public Animal(String name, String fname) {
		this.fname=fname;
		this.name=name;
	}
	
	
	

}
