package algoPrj.day12.다형성예제;

public class LY_dance extends Person{

	 @Override
	 public void dance() {
		 System.out.println("춤을 못 춰서 뒤에서 탬버린을 흔든다");
	    		
		

	}

}
