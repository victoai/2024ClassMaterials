package day12.다형성예제;

public class Kmj extends Person2{

	@Override
	public void dance() {
		System.out.println("노래를 부르며 춤을 춘다");
		
	}
	
}
