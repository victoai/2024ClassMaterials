package java_day12_다향성예제2;

public class JHDance extends Person {
	
	@Override
	public void dance() {
		System.out.println("막춤");
	}

}
