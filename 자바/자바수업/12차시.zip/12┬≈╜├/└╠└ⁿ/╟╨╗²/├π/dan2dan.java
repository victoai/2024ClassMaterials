package algoPrj.day12.다형성예제;

public class dan2dan extends Person {
	
	@Override
	public void dance() {
		System.out.println("댄스 투 댄스");
	}
	

}
