package day12.다형성예제.춤;

public class Dance_JH2 extends Person{
	@Override
	public void dance() {
		System.out.println("돌면서 손을 들고 춤을 춘다.");
	}

	
	
}
