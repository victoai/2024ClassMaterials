package day12다형성예제;

public class dy extends Person2  {
		@Override
		public void dance() {
			System.out.println("마구 몸을 흔든다");
			
		}
		
	

}
