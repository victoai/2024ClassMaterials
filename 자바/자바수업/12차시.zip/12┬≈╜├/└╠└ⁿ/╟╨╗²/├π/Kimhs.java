package day12.다형성예제_춤;

public class Kimhs extends Person {
	@Override
	public void dance() {
		System.out.println("한국무용을 춥니다.");
	}

}
