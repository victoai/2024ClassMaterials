package algoPrj.day12.다형성예제;

public class Singer extends Person {
	
	@Override
	public void dance() {
		System.out.println("노래를 부른다");
	}
	

}
