package day12.다형성예제;

public class DunDun2 extends Person2{
	@Override // Person의 public void dance()를 오버라이드
	public void dance2() {
		System.out.println("now let's 춤을춤을춤을춰요 wanna getout");
	}
}
