package 예제;

public class 병진 extends Person{
	@Override
	public void dance() {
		System.out.println("화려한 백덤블링을 구사한다."); 
	}
}
