package day0802.다형성예제;

public class Samba extends Person {

	@Override
	public void dance() {
		System.out.println("삼바를 춘다.");
	}
}
