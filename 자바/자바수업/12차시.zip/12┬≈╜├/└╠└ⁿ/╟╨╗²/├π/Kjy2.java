package day12.다형성예제;

public class Kjy extends Person2{

	@Override
	public void dance() {
		// TODO Auto-generated method stub
		
	}

}
