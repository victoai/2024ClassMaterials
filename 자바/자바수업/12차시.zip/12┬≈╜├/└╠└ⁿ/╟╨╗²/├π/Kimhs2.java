package day12.추상클래스;

public class Kimhs2 extends Person {

	@Override
	public void dance() {

		System.out.println("춤을 추지 않고 수면을 취합니다.");

	}

}
