package 다형성예제;

public class KJY extends Person {

	@Override
	public void dance() {
		System.out.println("각기춤을 추다");
	}
}
