package day11_상속_다형성;

public class Animal {

	public void 짖는다() {
		System.out.println( "짖는다");
	}
	
	
	public void 먹는다() {
		System.out.println( "먹는다");
	}
	
	public void 잠잔다() {
		System.out.println( "잠잔다");
	}

}
