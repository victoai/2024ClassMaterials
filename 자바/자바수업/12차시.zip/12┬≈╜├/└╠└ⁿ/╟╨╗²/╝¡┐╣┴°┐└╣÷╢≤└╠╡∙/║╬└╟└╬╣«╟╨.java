package day12;

public class 부의인문학 extends Library{
	public void already_R() {
		System.out.println("이미 반납하셨습니다.");
	}
}
