package day12.업다운캐스팅.예진님;

public class 부의인문학 extends Library{
	public void already_R() {
		System.out.println("이미 반납하셨습니다.");
	}
}
