package day12.업다운캐스팅.단야님;

public class 에자3수 extends 에이콘{   

	   public void Cool() {
	      System.out.println("자바 3회차 학생들은 멋지다");
	   }
	   
	   public void Fun() {
	      System.out.println("자바 3회차 학생들은 재밌다");
	   }
	   
	   public void Sexy() {
	      System.out.println("자바 3회차 학생들은 끝내준다");
	   }
	   
	   public void Succeed() {
	      System.out.println("자바 3회차 학생들은 성공한다");
	   }
	   
	   public void Meal() {
		      System.out.println("자바 3회차 학생들은 맛있게 먹는다");
		   }
	   
	}