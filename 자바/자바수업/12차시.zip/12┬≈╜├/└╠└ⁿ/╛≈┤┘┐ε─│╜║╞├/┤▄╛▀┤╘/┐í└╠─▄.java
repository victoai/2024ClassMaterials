package day12.업다운캐스팅.단야님;

public class 에이콘 {

	   public void Hongdae() {
	      System.out.println("에이콘은 홍대에 있다");
	   }
	   
	   public void Meal() {
	      System.out.println("에이콘 학생들은 밥먹는다");
	   }
	   
	   public void Elevator() {
	      System.out.println("에이콘에는 엘리베이터가 없다");
	   }
	   
	   public void Aircon() {
	      System.out.println("에이콘에는 에어컨 성능이 좋다");
	   }
	      
	}