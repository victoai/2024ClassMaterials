package day12.업다운캐스팅.병진님;

public class Animal {

	public void 짖는다() {
		System.out.println( "짖는다");
	}
	
	
	public void 먹는다() {
		System.out.println( "먹는다");
	}
	
	public void 잠잔다() {
		System.out.println( "잠잔다");
	}

}
