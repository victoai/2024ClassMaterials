package day15.정렬연습3;

public interface MYCoffeeYY {

	int YYcompare(Object o1,Object o2);
}
