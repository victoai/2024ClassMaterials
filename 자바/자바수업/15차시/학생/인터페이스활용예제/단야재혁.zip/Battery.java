package day15.핸드폰;

public interface Battery {
	public void getEnergy();
	public void getOutEnergy();

}
