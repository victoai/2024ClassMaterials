package store;

public interface StoreIn {
	public void Hello();
	public void menu();
}
