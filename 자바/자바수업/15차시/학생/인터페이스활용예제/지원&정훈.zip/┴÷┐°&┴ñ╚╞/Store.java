package store;

public class Store {
	
	public void store(StoreIn s) {
		s.Hello();
		s.menu();
	}
}
