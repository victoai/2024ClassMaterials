package 복습및정리.객체지향.다형성;

public class Animal {
	void 짖다() {
		
	}

}
