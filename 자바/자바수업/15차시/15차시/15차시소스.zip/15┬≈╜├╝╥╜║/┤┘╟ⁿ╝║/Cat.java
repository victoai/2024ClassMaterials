package 복습및정리.객체지향.다형성;

public class Cat extends Animal{
	@Override
	void 짖다() {
		// TODO Auto-generated method stub
		 System.out.println( "야옹");
	}

}
