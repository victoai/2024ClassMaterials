package 복습및정리.함수_매서드;

public class 매서드사용잇점 {

	public static void main(String[] args) {
		 
		
		System.out.println( "1. 높은 재사용성, 필요할 때 마다 호출할 수 있음");
		System.out.println( "2. 중복된 코드 제거,  코드이 량이 준다. , 유지보수가 우수해짐 ");
		System.out.println( "3. 프로그램으 구조화 (코드쪼개고 쪼개진코드에 이름 붙이기 => 함수 ) : 모든코드를 main에 두지 않겠다 .!!!! ");		
		System.out.println( "4. main에는 전체적인 프로그램 흐름에 두겠다!!!! ");
		
		
		
		/**
		 *  public static void main( String args[] ) {		 *  
		 *  
		 *    int[]  numArr  = new int[10];
		 *    initArr( numArr) ;
		 *    printArr( numArr);
		 *    sortArr( numArr);
		 *    printArr( numArr);  	
		 *    	   
		 *  }
		 * 
		 * 
		 */
	}

}
