package 복습및정리.객체지향.상속;

public class A {
	
	void 놀기() {
		System.out.println("놀기");
	}

}
