package 복습및정리.객체지향.상속;

public class Super키워드 {
	public static void main(String[] args) {
		
		
		System.out.println( "상속관계에서 부모의 멤버를 접근하는 참조형변수이다");
		
		
		D d  = new D();		
		d.super키워드사용하기();
		d.c매서드();
		d.super로부뫠서드c매서드호출하기();
		
		
		
	}

}
