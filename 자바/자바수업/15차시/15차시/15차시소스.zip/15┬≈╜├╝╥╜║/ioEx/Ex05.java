package javaprj.day0207.ioEx;

import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
	 
		
		
		Scanner sc = new Scanner( System.in);		
		String inputLine = sc.nextLine();		
		System.out.println( inputLine);
		
		sc.close();
 
	}

}
