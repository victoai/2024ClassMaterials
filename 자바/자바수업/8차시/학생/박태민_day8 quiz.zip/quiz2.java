package day08.quiz;

public class quiz2 {

	public static void main(String[] args) {
		// 별 5개를 출력하는 함수 만들기

		starry();
	}

	public static void starry() {
		int star = 5;
		for(int i = 0; i<star; i++) {
			System.out.print("*");
		}
	}

}
