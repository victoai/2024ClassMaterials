package day08.quiz;

public class quiz4 {

	public static void main(String[] args) {
		// "안녕하세요"를 출력하는 함수 만들기

		hi();
	}

	public static String hi() {
		String hello = "안녕하세요";
		System.out.println(hello);
		return hello;
	}

}
