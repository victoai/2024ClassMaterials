package day8.함수;

public class Q_4 {

	public static void main(String[] args) {
		//"안녕하세요"를 출력하는 함수 만들기
		
		showHello();
	}

	public static void showHello() {
		System.out.println("안녕하세요:)");
	}

}
