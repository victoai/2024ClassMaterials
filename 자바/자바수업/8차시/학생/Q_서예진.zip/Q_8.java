package day8.함수;

public class Q_8 {

	public static void main(String[] args) {
		//Integer.parseInt("25") ;   기능 만들어 보기
		
/* 		MyLib클래스 작성
       함수이름    int  parseInt( String  str) 
       char    ch = str.charAt(0) ;    // '2'
       char   ch2 = str.charAt(1) ;    // '5'
       int su=  Integer.parseInt("25") ;    
       프로그램에서 "25"  문자열 "25 " => 숫자로 바꿔주는 기능 25
*/
		
		String change = new String("25");
		
		stringToint(change);
	}

	public static void stringToint(String change) {
		int num = Integer.parseInt(change);
		System.out.println(num);
	}

}
