package day8.함수;

public class Q_2 {

	public static void main(String[] args) {
		//별 5개를 출력하는 함수 만들기
		
		star();
	}

	public static void star() {
		for(int i=0; i<5;i++) {
			System.out.print("*");
		}
	}

}
