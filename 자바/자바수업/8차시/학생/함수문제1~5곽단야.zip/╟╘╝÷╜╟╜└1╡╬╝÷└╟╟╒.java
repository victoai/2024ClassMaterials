package day8;

import java.util.Scanner;

public class 함수실습1두수의합 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//두 수의 합을 구하는 함수 만들기
		//별 5개를 출력하는 함수 만들기
		//원하는 별을 출력하는 함수 만들기
		//"안녕하세요"를 출력하는 함수 만들기
		//자신이 만든 화폐구하기를 함수 만들기
		
		//일주일간의 날씨정보를 반환하는 함수 만들기(날씨정보는 임의 작성)
		//짝수(2~10), 홀수(1~9)를 반환하는 함수 만들기
		//Integer.parseInt("25"); 기능 만들어 보기
		//MyLib클래스 작성
		//함수이름 int parseInt(String str)
			//char ch = str.charAt(0);	//'2'
			//char ch2 = str.charAt(1);	//'5'
		//int su = Integer.parseInt("25");
		//프로그램에서 "25" 문자열 "25" => 숫자로 바꿔주는 기능 25
		//자바에서 랜덤수 만들기
			//
	
	/*=================1===================*/
		int a = 0;
		int b = 0;
		
		int sum = numbers(a,b);
		System.out.println(sum);
		
	}

	public static int numbers(int a, int b) {
		
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		b = sc.nextInt();
		int sum = a + b;
		return sum;
		
	}
	

}
