package day0727;

import java.util.Scanner;

public class 함수실습Ex05 {

	public static void main(String[] args) {
		
		moneyCount();
	}

	public static void moneyCount() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("출장비를 입력하세요.");
		int in = sc.nextInt(); // 출장비 입력
		
		int[] cnt = new int[8];
		int[] money = { 50000, 10000, 5000, 1000, 500, 100, 50, 10 };
		
		// 매수 구하기
		for (int i = 0; i < cnt.length; i++) {
			cnt[i] = in / money[i];
			in = in % money[i];
			if(money[i]>=1000) {
				System.out.println(money[i] + "원 : " + cnt[i] + "장");
			}else {
				System.out.println(money[i] + "원 : " + cnt[i] + "개");
			}
			
		}
	}
	
}