package day0727;

import java.util.Arrays;
import java.util.Scanner;

public class 함수실습Ex09_parseInt_Fuction2 {

	public static void main(String[] args) {
		  int  rate = parseInt("10");		  
		  System.out.println(rate);
	}
	
	public static int parseInt( String str) {		
		int result=0;
		for( int i=0;  i< str.length() ;i++) {			
			char su_  = str.charAt(i);
			int su = su_-48;
			result = result * 10 +  su;		
		}	
		return result;			
	}
}