package day0727;

import java.util.Arrays;
import java.util.Scanner;

public class 함수실습Ex06 {

	public static void main(String[] args) {
		
		System.out.println("일주일간의 날씨를 입력하세요.");
		weather();
		
		
	}

	public static void weather() {
		Scanner sc = new Scanner(System.in);
		String[][] weather = new String[7][2];
		String[] days = {"월", "화", "수", "목", "금", "토", "일"};
		
		
		for(int i=0; i<weather.length; i++) {
			for(int j=0; j<weather[i].length; j++) {
				if(j==0) {
					weather[i][j] = days[i];
				}else {
					String weather_input = sc.next();
					weather[i][j] = weather_input;
				}
				
			}
		}
		
		// 2차원 배열은 for문 중첩 사용해서 출력
		for(String[] weather_print_line : weather) {
			for(String weather_print_row : weather_print_line) {
				 System.out.print(weather_print_row + " ");
			}
			System.out.println();
		}
	}

	
	
	
}