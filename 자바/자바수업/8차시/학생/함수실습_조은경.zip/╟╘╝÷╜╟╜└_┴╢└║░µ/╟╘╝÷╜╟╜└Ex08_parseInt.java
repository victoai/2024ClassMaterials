package day0727;

import java.util.Arrays;
import java.util.Scanner;

public class 함수실습Ex08_parseInt {

	public static void main(String[] args) {

		int result = Integer.parseInt("25"); // Integer.parseInt("문자열로 된 숫자만 입력 가능")
		System.out.println(result);

	}
}