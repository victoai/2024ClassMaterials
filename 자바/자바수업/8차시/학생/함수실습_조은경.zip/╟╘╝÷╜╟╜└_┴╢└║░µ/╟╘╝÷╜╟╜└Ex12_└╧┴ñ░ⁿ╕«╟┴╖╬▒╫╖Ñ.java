package day0727;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 함수실습Ex12_일정관리프로그램 {

	static String[] reg = new String[10];
	static Scanner sc = new Scanner(System.in);
	static int reg_cnt = 0;
	
	public static void main(String[] args) {
		
		System.out.println("메뉴 : 1.등록, 2.조회, 3.변경, 4.삭제, 5.종료");
		int menu; 
		
		loop : while(true) {
			menu = sc. nextInt();
			switch(menu) {
			case 1 : 
				registration();
				break;
			case 2 : 
				inquiry ();
				break;
			case 3 : 
				change();
				break;
			case 4 : 
				delete();
				break;
			case 5 : 
				System.out.println("종료");
				break loop;
			default :
				System.out.println("잘못된 입력입니다.");
				break;
			}
		}
	}

	public static int delete() {
		System.out.println("일정을 삭제하세요.");
		for(int i=0; i<reg_cnt; i++) {
			System.out.println(i+1 + "." + reg[i]);
		}
		System.out.println("삭제할 일정을 선택하세요.");
		int num = sc.nextInt();
		System.out.println(num + "을 삭제하겠습니다.");
		reg_cnt--;
		return reg_cnt;
	}

	public static void change() {
		System.out.println("일정을 변경하세요.");
		for(int i=0; i<reg_cnt; i++) {
			System.out.println(i+1 + "." + reg[i]);
		}
		System.out.println("변경할 일정을 선택하세요.");
		int num = sc.nextInt();
		reg[num-1]=sc.next();
	}

	public static void inquiry () {
		System.out.println("일정을 조회합니다.");
		for(int i=0; i<reg_cnt; i++) {
			System.out.println(i+1 + "." + reg[i]);
		}
	}

	public static int registration() {
		System.out.println("일정을 등록하세요.");
		reg[reg_cnt] = sc.next();
		reg_cnt++;
		return reg_cnt;
	}
}