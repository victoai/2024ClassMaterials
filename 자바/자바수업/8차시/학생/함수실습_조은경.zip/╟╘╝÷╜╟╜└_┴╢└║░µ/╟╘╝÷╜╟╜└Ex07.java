package day0727;

import java.util.Arrays;
import java.util.Scanner;

public class 함수실습Ex07 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("최대값을 입력하세요 : ");
		int num = sc.nextInt();

		odd(num);
		even(num);

	}

	
	// 홀수 출력 프로그램
	public static void odd(int num) {
		int[] odd = new int[(num / 2) + 1];
		int odd_cnt = 0;

		for (int i = 1; i <= num; i++) {
			if (i % 2 != 0) {
				odd[odd_cnt] = i;
				odd_cnt++;
			}
		}

		System.out.print("홀수 : ");
		for (int i = 0; i < odd.length; i++) {
			if (odd[i] != 0) { // 배열에 저장된 값이 0이 아닐 때 출력
				System.out.print(odd[i] + " ");
			}
		}
		System.out.println();
		
	}

	// 짝수 출력 프로그램
	public static void even(int num) {

		int[] even = new int[(num / 2) + 1];
		int even_cnt = 0;

		for (int i = 1; i <= num; i++) {
			if (i % 2 == 0) {
				even[even_cnt] = i;
				even_cnt++;
			}
		}

		System.out.print("짝수 : ");
		for (int i = 0; i < even.length; i++) {
			if (even[i] != 0) {
				System.out.print(even[i] + " ");
			}
		}
		System.out.println();
	}
}