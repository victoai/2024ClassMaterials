package day0727;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 함수실습Ex11_난수만들기2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("최솟값 : ");
		int min = sc.nextInt(); // 최소값
		System.out.print("최댓값 : ");
		int max = sc.nextInt(); // 최대값

		Random random = new Random();
		int randomNumber = random.nextInt(max - min + 1) + min;
		System.out.println("랜덤수 : " + randomNumber);

	}
}