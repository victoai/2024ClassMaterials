package day0727;

import java.util.Scanner;

public class 함수실습Ex01 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("두 수를 입력하세요");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		System.out.println("두 수의 합 : " + sumFunction(num1,num2));

	}

	public static int sumFunction(int num1, int num2) {
		int sum = 0;
		sum = num1 + num2;
		return sum;
	}

}
