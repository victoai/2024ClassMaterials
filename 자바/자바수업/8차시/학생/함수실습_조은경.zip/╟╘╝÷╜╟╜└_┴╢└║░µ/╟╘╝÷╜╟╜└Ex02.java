package day0727;

import java.util.Scanner;

public class 함수실습Ex02 {

	public static void main(String[] args) {

		star();
	}

	public static void star() {
		for (int i = 0; i < 5; i++) {
			System.out.print("*");
		}
		System.out.println();
	}

}
