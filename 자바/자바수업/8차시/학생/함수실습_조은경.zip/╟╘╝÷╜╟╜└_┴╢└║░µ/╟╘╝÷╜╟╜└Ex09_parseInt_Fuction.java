package day0727;

import java.util.Arrays;
import java.util.Scanner;

public class 함수실습Ex09_parseInt_Fuction {

	public static void main(String[] args) {

		parseInt();
		
	}

	public static void parseInt() {
		Scanner sc = new Scanner(System.in);
		String var = sc.next();

		char[] ch = new char[var.length()]; // 문자를 1개씩 저장하는 배열
		int[] mul = new int[var.length()]; // 자릿수 배열

		for (int i = mul.length - 1; i >= 0; i--) {
			if (i == mul.length - 1) {
				mul[i] = 1;
			} else {
				mul[i] = mul[i + 1] * 10;
			}

		}

		for (int i = 0; i < var.length(); i++) {
			ch[i] = var.charAt(i);
			System.out.print((ch[i] - 48) * mul[i] + " ");
		}
	}
}