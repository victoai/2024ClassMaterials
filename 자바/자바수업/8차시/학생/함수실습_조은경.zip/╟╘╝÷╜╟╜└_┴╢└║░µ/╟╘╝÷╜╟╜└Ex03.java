package day0727;

import java.util.Scanner;

public class 함수실습Ex03 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		star(num);
	}

	public static void star(int n) {
		for (int i = 0; i < n; i++) {
			System.out.print("*");
		}
		System.out.println();
	}

}
