package day0727;

import java.util.Scanner;

public class 함수실습Ex04 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("인삿말을 입력하세요.");
		String word = sc.nextLine();
		hello(word);
	}

	public static void hello(String word) {

		System.out.print(word);

	}

}
