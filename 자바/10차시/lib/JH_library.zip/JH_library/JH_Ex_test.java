package prj2;

import java.util.Scanner;

import jh_Ex.Jh_Ex01;


public class JH_Ex_test {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.print("숫자를 입력하세요: ");
		int num =sc.nextInt();
		Jh_Ex01.aa(num);
		
		

	}

}
