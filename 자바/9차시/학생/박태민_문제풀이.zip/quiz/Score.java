package day09.quiz;

public class Score {

// 학생성적

String name;
int kor;
int eng;
double avg;
}
