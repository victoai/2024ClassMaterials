package day0726;

import java.util.Scanner;

public class 배열문제6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] temperatures = { 27, 27, 28, 29, 30, 33, 32, 33, 32, 31, 31, 33, 33, 31 };

		int temperatures_min = temperatures[0]; // 배열이 첫번째 값으로 초기화
		for (int i = 0; i < temperatures.length; i++) {
			if (temperatures_min > temperatures[i]) {
				temperatures_min = temperatures[i];
			}
		}
		System.out.println("가장 낮은 기온 : " + temperatures_min);

	}
}