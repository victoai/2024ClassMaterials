package day0726;

import java.util.Scanner;

public class 배열문제3 {

	public static void main(String[] args) {

		int[] temperatures = { 27, 27, 28, 29, 30, 33, 32, 33, 32, 31, 31, 33, 33, 31 };

	
		int sum = 0;
		for (int i = 0; i < temperatures.length; i++) {
			sum += temperatures[i];
		}
		int avg = sum / (temperatures.length);
		System.out.println("평균기온 : " + avg);

		
	}
}