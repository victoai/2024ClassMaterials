package day0726;

import java.util.Scanner;

public class 배열문제 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] temperatures = { 27, 27, 28, 29, 30, 33, 32, 33, 32, 31, 31, 33, 33, 31 };

		for (int i = 0; i < temperatures.length; i++) {
			System.out.print(temperatures[i] + ", ");
			if (i == temperatures.length - 1) {
				System.out.println(temperatures[i]);
			}
		}
		
	}
}