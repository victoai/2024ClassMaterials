package day0726;

import java.util.Scanner;

public class 배열문제4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] temperatures = { 27, 27, 28, 29, 30, 33, 32, 33, 32, 31, 31, 33, 33, 31 };

		int sum = 0;

		// 평균기온 반복
		for (int i = 0; i < temperatures.length; i++) {
			sum += temperatures[i];
		}
		int avg = sum / temperatures.length;

		// 기온 비교
		int day_cnt = 0;// 일수
		for (int i = 0; i < temperatures.length; i++) {
			if (temperatures[i] > avg) {
				day_cnt++;
			}
		}
		System.out.println("평균기온 : " + avg);
		System.out.println("평균기온보다 높은 날 : " + day_cnt);

	}
}