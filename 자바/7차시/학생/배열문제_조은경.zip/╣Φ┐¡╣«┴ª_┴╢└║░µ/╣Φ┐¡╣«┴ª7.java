package day0726;

import java.util.Scanner;

public class 배열문제7 {

	public static void main(String[] args) {

		int[] temperatures = { 27, 27, 28, 29, 30, 33, 32, 33, 32, 31, 31, 33, 33, 31 };
		Scanner sc = new Scanner(System.in);
		
		int in;
		
		// 30이하의 수 입력여부
		System.out.println("30 이하의 수를 입력하세요.");
		while (true) {
			in = sc.nextInt();
			if (in < 30)
				break;
			System.out.println("수를 다시 입력하세요.");
		}
		
		//약수를 배열에 저장
		int[] divisor = new int[30];
		int divisor_cnt = 0;
		for(int i=1; i<=in ; i++) {
			if(in%i==0) {
				divisor[divisor_cnt] = i;
				divisor_cnt++;
			}
		}
		
		// 배열 출력
		System.out.println("입력한 수 : " + in);
		System.out.print("약수 : ");
		for(int i = 0; i<divisor_cnt; i++) {
			if(i==divisor_cnt-1) {
				System.out.println(divisor[i]);
			}else {
				System.out.print(divisor[i] + ", ");
			}
		}
		
		
		
	}
}