package funInterface;

public class B {

}
