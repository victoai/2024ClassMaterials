package java2.day3.reflect.animal;


public class Animal {	
	public void bark() {  
		  
	}
}
