package day1.generic.wildcard;

public class Fruit {

}
