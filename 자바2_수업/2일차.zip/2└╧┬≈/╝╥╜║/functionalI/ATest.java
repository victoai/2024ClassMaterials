package day2.lamda.functionalI;

public class ATest {

	public static void main(String[] args) {
		 
		
		A a = new A();
		a.hi();
		
	}

}
