package day1.generic.printer;

public class Water {	
	String content="water";

	@Override
	public String toString() {
		return "water [content=" + content + "]";
	}

}
