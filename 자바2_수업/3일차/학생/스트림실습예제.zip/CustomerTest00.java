package java2prj1.day3.stream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class CustomerTest00 {

	public static void main(String[] args) {

		List<Customer> customers = new ArrayList<>();
		customers.add(new Customer(1, "홍길동", "vvip", 124000));
		customers.add(new Customer(2, "징기즈칸", "vip", 23800));
		customers.add(new Customer(3, "테무르", "vvip", 111500));
		customers.add(new Customer(4, "장보고", "bronze", 8300));
		customers.add(new Customer(5, "나폴레옹", "vip", 21200));
		customers.add(new Customer(6, "임꺽정", "bronze", 9400));
		customers.add(new Customer(7, "비룡", "vvip", 142000));
		customers.add(new Customer(8, "네티", "vip", 42900));
		customers.add(new Customer(9, "마스", "bronze", 9600));
		customers.add(new Customer(10, "주피터", "vip", 51100));

		long vvipCount = customers.stream().filter(customer -> customer.getGrade().equals("vvip")).count();
		System.out.println("고객등급이 vvip인 사람 수 : " + vvipCount);

		ArrayList<Customer> vipCustomers = (ArrayList<Customer>) customers.stream().filter(customer -> customer.getGrade().equals("vip"))
				.collect(Collectors.toList());
		System.out.println("고객등급이 vip인 고객 : ");
		vipCustomers.forEach(customer -> System.out.println(customer.getName()));

		ArrayList<Customer> sortedCustomers = (ArrayList<Customer>)customers.stream()
				.sorted(Comparator.comparingInt(Customer::getPoint).reversed()).collect(Collectors.toList());
		System.out.println("포인트 높은 순으로 고객 정렬 : ");
		sortedCustomers.forEach(customer -> System.out.println(customer.getName() + " -> 포인트: " + customer.getPoint()));
	}

}
