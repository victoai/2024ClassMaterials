package java2prj1.day3.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class 스트링스트림예제 {

	public static void main(String[] args) {

		String[] stringArray = { "사과", "바나나", "체리", "자두", "샤인머스켓" };

		ArrayList<String> stringList = new ArrayList<>(Arrays.asList(stringArray));

		Stream<String> stringArrayStream = Arrays.stream(stringArray);
		ArrayList<String> filteredArray = (ArrayList<String>) stringArrayStream.filter(str -> str.length() >= 3)
				.collect(Collectors.toList());

		Stream<String> stringListStream = stringList.stream();
		ArrayList<String> lowercaseList = (ArrayList<String>) stringListStream.map(String::toLowerCase)
				.collect(Collectors.toList());

		System.out.println("다섯글자 이상만 나오게하기 : " + filteredArray);

		System.out.println("소문자로 바꾸기 : " + lowercaseList);
	}
}

