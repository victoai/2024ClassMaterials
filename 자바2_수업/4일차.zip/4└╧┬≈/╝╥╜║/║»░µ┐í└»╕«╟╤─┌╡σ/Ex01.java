package day4.변경에유리한코드;

public class Ex01 {

	public static void main(String[] args) {
		 
		
		//Dog  -> Cat으로 변경된다면  변경의 포인트를 확인하자 !!
		Dog dog = new Dog();
		dog.bark();
		
		
		Dog dog2 = new Dog();
		dog2.bark();
		 

	}

}
