package java2.test;

public interface panda {
	
	public void name() ;
}
