package java2.test;

public class 아이바오 implements panda{

	@Override
	public void name() {
		System.out.println("아이바오🐼");
		
	}

}
