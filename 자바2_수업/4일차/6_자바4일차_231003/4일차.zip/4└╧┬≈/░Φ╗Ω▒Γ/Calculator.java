package java2.day4.변경이유리한코드.계산기;

public interface Calculator {
	
	int add( int su1, int su2);

}
