package java2.day4.변경이유리한코드.animal;

public class Animal {	
	public void bark() {  
		  
	}
}
