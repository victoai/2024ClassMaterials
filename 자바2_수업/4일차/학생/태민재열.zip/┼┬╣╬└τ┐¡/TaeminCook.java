package 태민재열;

public class TaeminCook extends Cook {

	@Override
	public void Bulgogi() {
		System.out.println("\"박태민\"이 불고기를 요리한다");
	}

	@Override
	public void Ssambab() {
		System.out.println("\"박태민\"이 쌈밥을 요리한다");
	}

	@Override
	public void Bbulbaek() {
		System.out.println("\"박태민\"이 돼지불백을 요리한다");
	}

}
