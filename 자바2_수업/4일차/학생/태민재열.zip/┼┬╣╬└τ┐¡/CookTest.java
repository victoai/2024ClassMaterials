package 태민재열;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

public class CookTest {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws ClassNotFoundException, FileNotFoundException, InstantiationException,
			IllegalAccessException, IOException {
		
		// 메뉴리스트
		ArrayList<String> list = new ArrayList<>();
		list.add("1. 불고기");
		list.add("2. 쌈밥");
		list.add("3. 돼지불백");
		
		boolean open = true;
		loop: while (open) {		// open인 동안에 반복
			System.out.println("=========원하는 버튼을 선택하세요=========\n1.메뉴조회 2.주문하기 3.종료");
			String menu_ = sc.nextLine();	// 메뉴 번호를 입력
			int menu = Integer.parseInt(menu_);		// String to int
			switch (menu) {
			case 1: {
				System.out.println("==Menu List==");
				for (String s : list) {				// 메뉴리스트 출력
					System.out.println(s);
				}
				break;
			}
			case 2: {
				Cook cook = getCook();
				System.out.println("주문하시겠습니까");
				for (String s : list) {				// 주문을 위한 메뉴리스트 출력
					System.out.println(s);
				}
				String mlist_ = sc.nextLine();			// 음식번호를 입력
				int mlist = Integer.parseInt(mlist_);		// String to int
				switch (mlist) {
				case 1:
					cook.Bulgogi();
					String result1 = list.get(0);
					System.out.println(result1 + "완성!");
					break;
				case 2:
					cook.Ssambab();
					String result2 = list.get(1);
					System.out.println(result2 + "완성!");
					break;
				case 3:
					cook.Bbulbaek();
					String result3 = list.get(2);
					System.out.println(result3 + "완성!");
					break;
				default:
					System.out.println("잘못된 입력입니다.");
				}
				break;
			}
			case 3: {
				System.out.println("가게를 나갑니다");
				break loop;
			}
			default:
				System.out.println("잘못된 입력입니다.");
			}
		}

	}

	private static Cook getCook() throws ClassNotFoundException, FileNotFoundException, IOException,
			InstantiationException, IllegalAccessException {
		Properties p = new Properties();
		p.load(new FileReader("src/태민재열/config.txt"));

		String className = p.getProperty("cook");
		Class clazz = Class.forName(className);
		Cook cook = (Cook) clazz.newInstance();

		return cook;
	}
}
