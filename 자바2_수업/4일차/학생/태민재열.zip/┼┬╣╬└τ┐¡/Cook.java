package 태민재열;

public class Cook {
	public void Bulgogi() {
		System.out.println("불고기");
	}
	
	public void Ssambab() {
		System.out.println("쌈밥을 요리한다");
	}
	
	public void Bbulbaek() {
		System.out.println("돼지불백을 요리한다");
	}
}
