package 태민재열;

public class JaeyeolCook extends Cook {

	@Override
	public void Bulgogi() {
		System.out.println("\"김재열\"이 불고기를 요리한다");
	}

	@Override
	public void Ssambab() {
		System.out.println("\"김재열\"이 쌈밥을 요리한다");
	}

	@Override
	public void Bbulbaek() {
		System.out.println("\"김재열\"이 돼지불백을 요리한다");
	}

}
