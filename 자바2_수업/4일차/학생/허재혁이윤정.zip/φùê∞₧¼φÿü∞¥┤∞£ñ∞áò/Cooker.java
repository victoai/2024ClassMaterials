package day4.Ex;

public class Cooker {
	
	String name;
	String age;

	public Cooker(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return "Cooker [name=" + name + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public Cooker() {
		this("기본이름");
	}
	
	public void cookerPrintInfo() {
		System.out.println("name=" + name + "age=" + age);
		
	}
	
	public void cookermethod(String a,String b) {
		System.out.println("name=" +a + "age" +b);
	}

}
