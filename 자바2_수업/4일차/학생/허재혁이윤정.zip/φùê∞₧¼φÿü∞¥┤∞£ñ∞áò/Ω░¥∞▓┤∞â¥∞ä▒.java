package day4.Ex;

import day4.reflect.Member;

public class 객체생성 {
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
		
		
		Cooker c = new Cooker();
		
		Class clazz = c.getClass();
		
		Cooker cooker = (Cooker) clazz.newInstance();
		c.cookermethod("요리사1","32");
		

	}

}
