package day4.Ex;

public class CookH extends Cook {
	@Override
	public void pigbool() {
		System.out.println("허재혁요리사의 돼지불백");
	}

	@Override

	public void ssam() {
		System.out.println("허재혁요리사의 모둠쌈밥");
	}

	@Override

	public void boolg() {
		System.out.println("허재혁요리사의 불고기된장찌게");
	}

}
