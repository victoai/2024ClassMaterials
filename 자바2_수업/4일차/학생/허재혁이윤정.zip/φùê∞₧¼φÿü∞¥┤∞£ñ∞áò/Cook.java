package day4.Ex;

public class Cook {
	
	public void pigbool() {
		System.out.println("돼지불백");
	}
	
	public void ssam() {
		System.out.println("모둠쌈밥");
	}
	
	public void boolg() {
		System.out.println("불고기된장찌게");
	}

}
