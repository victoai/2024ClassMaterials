package day4.Ex;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class 매서드호출 {
	
	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		Cooker c = new Cooker();
		c.cookerPrintInfo();
		c.cookermethod("요리사3","23");
		
		Class clazz = Class.forName("day4Ex.Cooker");
		
		Method method = clazz.getDeclaredMethod("cookerPrintInfo");
		method.invoke(c);
		
		Method method2 = clazz.getDeclaredMethod("cookermethod", String.class, String.class);
		method2.invoke(c, "요리사5","23");
		
	
	}

}
