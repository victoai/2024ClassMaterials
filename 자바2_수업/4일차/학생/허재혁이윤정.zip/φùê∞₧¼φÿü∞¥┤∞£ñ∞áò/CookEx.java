package day4.Ex;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;


	

	public class CookEx {
	    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException,
	            InstantiationException, IllegalAccessException {

	        Store store = new Store();
	        Cook cook = new CookH(); 
	        store.setCook(cook);

	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            System.out.println("1. 주문하기");
	            System.out.println("2. 메뉴 보여주기");
	            System.out.println("3. 종료");
	            int menu = scanner.nextInt();
	            scanner.nextLine(); 

	            switch (menu) {
	                case 1:
	                    store.orderDish();
	                    break;
	                case 2:
	                    store.showMenu();
	                    break;
	                case 3:
	                    System.out.println("프로그램을 종료합니다.");
	                    scanner.close();
	                    System.exit(0);
	                default:
	                    System.out.println("잘못된 선택입니다.");
	                    break;
	            }
	        }
	    }
	}

	// 한식당 클래스
	class Store {
	    private Cook cook;

	    public void setCook(Cook cook) {
	        this.cook = cook;
	    }

	    public void orderDish() {
	        if (cook != null) {
	            System.out.println("요리를 선택하세요:");
	            System.out.println("1. 돼지불백");
	            System.out.println("2. 모둠쌈밥");
	            System.out.println("3. 불고기된장찌게");
	            Scanner scanner = new Scanner(System.in);
	            int cooking = scanner.nextInt();
	            scanner.nextLine(); 

	            switch (cooking) {
	                case 1:
	                    cook.pigbool();
	                    break;
	                case 2:
	                    cook.ssam();
	                    break;
	                case 3:
	                    cook.boolg();
	                    break;
	                default:
	                    System.out.println("잘못된 선택입니다.");
	            }
	        } else {
	            System.out.println("요리사가 없습니다.");
	        }
	    }

	    public void showMenu() {
	        System.out.println("한식당 메뉴:");
	        System.out.println("1. 돼지불백");
	        System.out.println("2. 모둠쌈밥");
	        System.out.println("3. 불고기된장찌게");
	    }
	}