package 김민규_김민지_실습;

public class Cafe {

	
	public void pet() {
		System.out.println("동물친구들");
	}

	
}
