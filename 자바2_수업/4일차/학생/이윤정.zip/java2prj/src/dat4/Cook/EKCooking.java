package dat4.Cook;

public class EKCooking implements Cook {

	@Override
	public void 돼지불백() {
		System.out.println("조은경 요리사가 만든 돼지불백");
	}

	@Override
	public void 모둠쌈밥() {
		System.out.println("조은경 요리사가 만든 모둠쌈밥");
	}

	@Override
	public void 카레라이스() {
		System.out.println("조은경 요리사가 만든 카레라이스");
	}

	
	
	
}
