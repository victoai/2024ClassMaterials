package dat4.Cook;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class Main {
	
	

	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, InstantiationException, IllegalAccessException, IOException {
		
		Cook cook = getCook();
		cook.돼지불백();
		cook.모둠쌈밥();
		cook.카레라이스();
		
	}

	private static Cook getCook() throws FileNotFoundException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
	
		Properties p = new Properties();
		p.load(new FileReader("src/dat4/Cook/config.txt"));
		
		String className = p.getProperty("Cook");
		
		
		Class c = Class.forName(className);
		Cook cook = (Cook) c.newInstance();
		
		
		return cook;
	}

}
