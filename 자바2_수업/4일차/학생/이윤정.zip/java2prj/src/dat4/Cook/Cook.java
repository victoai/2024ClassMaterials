package dat4.Cook;

public interface Cook {
	
	public void 돼지불백();
	
	public void 모둠쌈밥();
	
	public void 카레라이스();	//	구현부가 없는 추상메소드
	
//	public static void 김치찌개() {
//	}

}
