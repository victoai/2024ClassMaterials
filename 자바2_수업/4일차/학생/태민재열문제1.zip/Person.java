package reflect;

public class Person {

	private String name;
    private int age;
    
    public Person() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
    
    public void introduce(String name, int age) {
    	System.out.println("안녕하세요, 저는 " + name + "이고, " + age + "살입니다.");
    }
}
