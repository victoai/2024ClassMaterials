package reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Introduce {

	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		Class c = Class.forName("reflect.Person");
		// 메소드 호출
		Constructor ct = c.getDeclaredConstructor();
		Person p =(Person) ct.newInstance();
		p.introduce("박태민", 31);
		p.introduce("김재열", 27);

		// 클래스 정보출력
		Field[] fields = c.getDeclaredFields();
		System.out.println("\n필드 정보 출력");
		for (Field f : fields) {
			System.out.println(f);
		}
		Method[] methods = c.getDeclaredMethods();
		System.out.println("메소드 정보 출력");
		for (Method m : methods) {
			System.out.println(m);
		}
	}

}
