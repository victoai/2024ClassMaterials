package java2prj1.day4.연습;

public interface Cook {
    void makeDish();
}
