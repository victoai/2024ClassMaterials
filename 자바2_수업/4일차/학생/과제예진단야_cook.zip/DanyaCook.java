package java2prj1.day4.연습;

public class DanyaCook implements Cook {
    @Override
    public void makeDish() {
        System.out.println("DanyaCook가 한식을 만듭니다.");
    }
}
