package day4.실습;

public class 이윤요리사 implements Cook{

	@Override
	public String 돼지불백() {
		// TODO Auto-generated method stub
		return "이윤돼지불백";
	}

	@Override
	public String 모둠쌈밥() {
		// TODO Auto-generated method stub
		return "이윤모둠쌈밥";
	}

	@Override
	public String 불고기된장찌게() {
		// TODO Auto-generated method stub
		return "이윤불고기된장찌게";
	}
	
	 

}
