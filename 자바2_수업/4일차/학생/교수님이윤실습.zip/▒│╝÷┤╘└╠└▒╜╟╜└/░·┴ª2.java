package day4.실습;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import day4.변경에유리한코드.Animal;

public class 과제2 {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		
		//Cook cook = new 이윤정요리사();
		
		Properties p = new Properties();
		p.load(new FileReader("src/day4/실습/cook.txt"));
		String className = p.getProperty("cook");		
		Class clazz = Class.forName(className);
		Cook cook = (Cook)clazz.newInstance();
		 
		//
		Scanner sc = new Scanner(System.in);
		System.out.println("주문을 받습니다");
		System.out.println("돼지불백");
		System.out.println("모둠쌈밥");
		System.out.println("불고기된장찌게");
		
		
		String orderMenu ="";
		orderMenu=sc.next();
		
		
		System.out.println("주문한 것은"+orderMenu+"입니다");
		
		String resultFood=""; 
		if(orderMenu.equals("돼지불백")) {
			resultFood=cook.돼지불백();
		}else if(orderMenu.equals("모둠쌈밥")){
			resultFood=cook.모둠쌈밥();
		}else if(orderMenu.equals("불고기된장찌게")) {
			resultFood=cook.불고기된장찌게();
		}
		
		System.out.println(resultFood);
		
		
		
		
		
		
		
		
	}
}
