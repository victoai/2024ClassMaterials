package day4.실습;

public class 이윤정요리사 implements Cook{

	@Override
	public String 돼지불백() {
		// TODO Auto-generated method stub
		return "이윤정돼지불백";
	}

	@Override
	public String 모둠쌈밥() {
		// TODO Auto-generated method stub
		return "이윤정모둠쌈밥";
	}

	@Override
	public String 불고기된장찌게() {
		// TODO Auto-generated method stub
		return "이윤정불고기된장찌게";
	}

	
}
