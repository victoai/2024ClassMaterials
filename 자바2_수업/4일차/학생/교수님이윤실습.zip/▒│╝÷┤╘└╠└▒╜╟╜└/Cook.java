package day4.실습;

public interface Cook {	 
	public String 돼지불백() ;
	public String 모둠쌈밥() ;
	public String 불고기된장찌게() ;   
}
