package java2prj1.day4.연습;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Q_1_Food호출 {

	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Food f = new Food();
		//f.printInfo();
		
		Class clazz = Class.forName("java2prj1.day4.연습.Food");
		
		Method method = clazz.getDeclaredMethod("printInfo");
		method.invoke(f);
	}

}
