package java2prj1.day4.연습;

public class YejinCook implements Cook {
    @Override
    public void makeDish() {
        System.out.println("YejinCook가 요리를 만듭니다.");
    }
}