package java2prj1.day4.연습;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Q_1_Food클래스정보출력 {

	public static void main(String[] args) throws ClassNotFoundException {
		Class clazz = Class.forName("java2prj1.day4.연습.Food");
		Field[] fields = clazz.getDeclaredFields();
		for(Field f : fields) {
			System.out.println(f);
		}
		Method[] methods = clazz.getDeclaredMethods();
		for(Method m : methods) {
			System.out.println(m);
		}

	}

}
