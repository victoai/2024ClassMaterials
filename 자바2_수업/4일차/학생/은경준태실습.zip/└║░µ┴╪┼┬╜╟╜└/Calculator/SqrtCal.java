package java2.calculator;

public class SqrtCal implements Calculator{


	@Override
	public int intCal(int su1, int su2) {
		return 0;
	}

	@Override
	public double doubleCal(double su1) {
		return Math.sqrt(su1);
	}

}
