package java2.calculator;

public interface Calculator {

	int intCal(int su1, int su2);
	double doubleCal(double su1);
	
}
