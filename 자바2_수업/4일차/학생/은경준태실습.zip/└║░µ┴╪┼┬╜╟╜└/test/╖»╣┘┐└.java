package java2.test;

public class 러바오 implements panda{

	@Override
	public void name() {
		System.out.println("러바오🐼");
		
	}

}
