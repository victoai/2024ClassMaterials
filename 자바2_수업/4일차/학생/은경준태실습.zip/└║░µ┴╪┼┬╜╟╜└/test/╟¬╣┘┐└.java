package java2.test;

public class 푸바오 implements panda{

	@Override
	public void name() {
		System.out.println("푸바오🐼");
		
	}

}
