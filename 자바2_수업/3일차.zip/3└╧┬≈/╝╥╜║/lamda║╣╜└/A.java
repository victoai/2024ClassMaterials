package day3.day3.lamda복습;

public class A {
	
	public  void  hi() {
		System.out.println( "hi");
	}
	
	
	
	
	public static void main(String[] args) {
		A a= new A();
		a.hi();
	}

}


/*
   자바에서 매서드를 만들고 호출하는 방법
   
   1. 클래스를 만든다 - 매서드작성하기
   2. 클래스로 객체를 생성한다
   3. 객체의 매서드를 호출한다



*/