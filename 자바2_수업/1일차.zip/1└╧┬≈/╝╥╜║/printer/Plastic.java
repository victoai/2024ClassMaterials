package day1.generic.printer;

public class Plastic  extends Material{
	
	String content="plastic";

	@Override
	public String toString() {
		return "Plastic [content=" + content + "]";
	}
	
	

}
