package day1.generic.printer;

public class Powder  extends Material{
	String content="powder";

	@Override
	public String toString() {
		return "Powder [content=" + content + "]";
	} 
}
