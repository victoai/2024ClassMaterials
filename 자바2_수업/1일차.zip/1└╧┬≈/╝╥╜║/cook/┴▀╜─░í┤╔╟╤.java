package day1.interfaceEx.cook;

interface 중식가능한{
     ;
    public String  탕수육만들기();
    
}
