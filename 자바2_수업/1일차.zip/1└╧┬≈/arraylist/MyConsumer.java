package java2.generic.arraylist;

public interface MyConsumer {
	 public void accept( Object t);
}
