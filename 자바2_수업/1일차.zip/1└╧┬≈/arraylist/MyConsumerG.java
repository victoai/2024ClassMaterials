package java2.generic.arraylist;

public interface MyConsumerG< T>{
	 public void accept( T t);
}
