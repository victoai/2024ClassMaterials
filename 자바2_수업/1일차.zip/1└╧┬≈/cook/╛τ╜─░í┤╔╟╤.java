package java2.interfaceEx.cook;

interface 양식가능한{
    public String  스파게티만들기();
    public String  피자만들기();
    public String  돈까스만들기(); 
}

