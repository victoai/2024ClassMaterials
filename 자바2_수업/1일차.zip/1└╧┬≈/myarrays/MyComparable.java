package java2.myarrays;

public interface MyComparable {
	int compareTo(Object obj);
}
