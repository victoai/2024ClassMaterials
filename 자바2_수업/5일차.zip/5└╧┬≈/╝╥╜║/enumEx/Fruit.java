package day5.enumEx;


public enum Fruit {
    APPLE, BANANA 
}