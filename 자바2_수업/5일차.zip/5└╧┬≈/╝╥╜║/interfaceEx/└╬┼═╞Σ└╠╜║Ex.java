package day5.interfaceEx;

public class 인터페이스Ex {

	public static void main(String[] args) {
		 

	}

}
