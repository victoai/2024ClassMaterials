package day5.interfaceEx.학생.김병진;

public interface SomethingDoI {
	public void bj();
}
