package day5.interfaceEx.학생.이정훈;

public interface SomethingDoI {
  public void doing();
}
